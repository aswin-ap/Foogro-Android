package com.example.foodappandroid.util;

public interface LogoutListener {
    void logOut();
}
