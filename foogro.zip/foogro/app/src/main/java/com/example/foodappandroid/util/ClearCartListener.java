package com.example.foodappandroid.util;

public interface ClearCartListener {
    void clearCart();
}
