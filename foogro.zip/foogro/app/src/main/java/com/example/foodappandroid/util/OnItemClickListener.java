package com.example.foodappandroid.util;

public interface OnItemClickListener {
    public void onItemClick(Integer position);
}
