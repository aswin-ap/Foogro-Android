package com.example.foodappandroid.ui.profile;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import com.example.foodappandroid.BaseActivity;
import com.example.foodappandroid.R;
import com.example.foodappandroid.data.preferences.SessionManager;
import com.example.foodappandroid.databinding.ActivityProfileBinding;
import com.example.foodappandroid.model.OrderItemModel;
import com.example.foodappandroid.ui.home.HomeActivity;
import com.example.foodappandroid.ui.order.OrderDetailsActivity;
import com.example.foodappandroid.ui.signup.SignupActivity;
import com.example.foodappandroid.util.NetworkManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ProfileActivity extends BaseActivity {
    private ActivityProfileBinding binding;
    private SessionManager sessionManager;
    private FirebaseFirestore fb;
    private String currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initView();
        setupObserver();
    }

    private void setupObserver() {
        if (NetworkManager.isNetworkAvailable(ProfileActivity.this)) {
            showLoading(this);
            fb.collection("user")
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                hideLoading();
                                for (QueryDocumentSnapshot documentSnapshot : task.getResult()) {
                                    if (documentSnapshot.get("userid").toString().equals(currentUserId)) {
                                        binding.editName.setText(documentSnapshot.get("name").toString());
                                        binding.editEmail.setText(documentSnapshot.get("email").toString());
                                        binding.textMobile.setText(documentSnapshot.get("mobile").toString());
                                        binding.tvPassword.setText(documentSnapshot.get("password").toString());
                                    }
                                }
                            }
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    hideLoading();
                    showToast(ProfileActivity.this, e.getMessage());
                }
            });
        } else {
            showSnackBar(binding.getRoot(), getString(R.string.check_internet));
        }
    }

    private void initView() {
        fb = getFireStoreInstance();
        sessionManager = new SessionManager(ProfileActivity.this);
        currentUserId = sessionManager.getUserId();
        getSupportActionBar().hide();
        binding.imageClose.setOnClickListener(v -> onBackPressed());
        binding.textYourOrders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this,OrderDetailsActivity.class);
                startActivity(intent);
                finish();
            }
        });
        binding.ivEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setupEditFields();
                binding.layoutConfirmPassword.setVisibility(View.VISIBLE);
            }
        });
        binding.buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (binding.tvConfirmPassword != null && !binding.tvConfirmPassword.getText().toString().isEmpty()) {
                    if (binding.tvPassword.getText().toString().equals(binding.tvConfirmPassword.getText().toString())) {
                        updateProfile();
                    } else {
                        showToast(ProfileActivity.this,"Password validation failed");
                    }
                } else {
                    updateProfile();
                }
            }
        });
    }

    private void updateProfile() {
        showLoading(this);
        Map<String, Object> user = new HashMap<>();
        user.put("name", binding.editName.getText().toString());
        user.put("email", binding.editEmail.getText().toString());
        user.put("password", binding.tvPassword.getText().toString());
        user.put("mobile", binding.textMobile.getText().toString());

        FirebaseFirestore fireStoreInstance = getFireStoreInstance();
        fireStoreInstance.collection("user")
                .document(sessionManager.getDocumentId())
                .update(user)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        hideLoading();
                        showToast(ProfileActivity.this, getString(R.string.update_success));
                        makeNotEditable();
                        setupObserver();
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                hideLoading();
                showToast(ProfileActivity.this, getString(R.string.error));
            }
        });
    }

    private void setupEditFields() {
        makeEditable(binding.editName);
        makeEditable(binding.editEmail);
        makeEditable(binding.textMobile);
        makeEditable(binding.tvPassword);
        binding.buttonUpdate.setVisibility(View.VISIBLE);
    }

    private void makeNotEditable() {
        makeNonEditable(binding.editName);
        makeNonEditable(binding.editEmail);
        makeNonEditable(binding.textMobile);
        makeNonEditable(binding.tvPassword);
        binding.buttonUpdate.setVisibility(View.GONE);
        binding.layoutConfirmPassword.setVisibility(View.GONE);

    }

    private void makeEditable(TextInputEditText view) {
        view.setEnabled(true);
        view.setFocusable(true);
    }

    private void makeNonEditable(TextInputEditText view) {
        view.setEnabled(false);
        view.setFocusable(false);
    }
}